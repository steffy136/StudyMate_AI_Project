from typing import Annotated, Literal

from pydantic import BaseModel, ConfigDict, Field, StringConstraints

Text = Annotated[str, StringConstraints(strip_whitespace=True, min_length=1)]
ID = Annotated[Text, Field(max_length=80)]
Index = Annotated[int, Field(ge=0, le=3)]
SummaryMode = Literal["quick", "standard", "detailed"]
ExamMode = Literal["quick_revision", "important_questions", "short_answers", "descriptive_answers"]


class Schema(BaseModel):
    model_config = ConfigDict(strict=True, extra="forbid")


class DocumentRequest(Schema):
    document_id: ID


class GenerationRequest(DocumentRequest):
    regenerate: bool = False


class SummaryRequest(GenerationRequest):
    mode: SummaryMode = "standard"


class TutorRequest(GenerationRequest):
    question: Annotated[Text, Field(max_length=2000)]
    explanation_mode: Literal["simple", "academic", "exam-ready"] = "simple"
    knowledge_mode: Literal["strict", "extended"] = "strict"


class QuizRequest(GenerationRequest):
    count: Literal[5, 10, 15, 20] = 5
    difficulty: Literal["easy", "medium", "hard"] = "medium"
    topic: Annotated[Text, Field(max_length=200)] | None = None


class Selection(Schema):
    question_id: ID
    option_index: Index


class SubmitRequest(DocumentRequest):
    quiz_id: ID
    answers: Annotated[list[Selection], Field(max_length=20)]


class FeedbackRequest(GenerationRequest):
    result_id: ID


class FlashcardRequest(GenerationRequest):
    count: Literal[10, 15, 20] = 10


class ExamRequest(GenerationRequest):
    mode: ExamMode = "quick_revision"


class Section(Schema):
    topic: Text
    explanation: Text


class Summary(Schema):
    title: Text
    overview: Text
    major_topics: Annotated[list[Text], Field(min_length=1)]
    topic_explanations: Annotated[list[Section], Field(min_length=1)]
    key_concepts: Annotated[list[Text], Field(min_length=1)]
    definitions: list[Section]
    key_takeaways: Annotated[list[Text], Field(min_length=1)]
    formulas: list[Text]


class Source(Schema):
    source_type: Literal["pdf", "txt"]
    page: int | None
    line_start: int | None
    line_end: int | None
    excerpt: Annotated[Text, Field(max_length=1000)]


class Tutor(Schema):
    answer: Text
    explanation: Text
    document_supported_content: str
    supplementary_content: str
    sources: Annotated[list[Source], Field(max_length=8)]
    follow_up_suggestions: Annotated[list[Text], Field(max_length=5)]
    sufficient_document_evidence: bool


class Question(Schema):
    question_id: ID
    question: Text
    options: Annotated[list[Text], Field(min_length=4, max_length=4)]
    correct_index: Index
    explanation: Text
    concept: Text
    sources: Annotated[list[Source], Field(max_length=3)]


class Quiz(Schema):
    topic_supported: bool
    questions: Annotated[list[Question], Field(max_length=20)]


class Feedback(Schema):
    overall_summary: Text
    strengths: list[Text]
    concepts_to_improve: list[Text]
    important_mistakes: list[Text]
    revision_recommendations: Annotated[list[Text], Field(min_length=1)]
    study_plan: Annotated[list[Text], Field(min_length=1)]


class Card(Schema):
    card_id: ID
    front: Text
    back: Text
    concept: Text


class Flashcards(Schema):
    cards: Annotated[list[Card], Field(min_length=10, max_length=20)]


class PracticeQuestion(Schema):
    question: Text
    model_answer: Text | None


class Exam(Schema):
    title: Text
    sections: list[Section]
    questions: list[PracticeQuestion]

