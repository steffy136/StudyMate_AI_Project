# StudyMate AI

StudyMate AI turns selectable-text PDFs and TXT notes into summaries, document-grounded tutoring, quizzes, flashcards, and exam preparation. The app runs locally in your browser and uses Google Gemini for AI features.

## Requirements

- Windows with **Python 3.13.2**, the version verified for this package. Check it with `py -3.13 --version`.
- Internet access to install dependencies and use Gemini.
- Gemini is already configured in the included private `.env`. No manual API key setup is required. Model availability and quotas depend on the configured Google project.

## Install and configure

1. Extract `StudyMate-AI.zip` in File Explorer. Open PowerShell in the extracted `StudyMate-AI` folder that contains `app.py`. A path with spaces is fine.
2. Create the virtual environment and install the pinned dependencies:

   ```powershell
   py -3.13 -m venv .venv
   .\.venv\Scripts\python.exe -m pip install -r requirements.txt
   .\.venv\Scripts\python.exe -m pip check
   ```

3. Leave the included `.env` beside `app.py`. It already contains the working Gemini configuration and a newly generated Flask signing secret. Keep the ZIP and `.env` private.

## Run the app

```powershell
.\.venv\Scripts\python.exe app.py
```

Open [StudyMate AI](http://127.0.0.1:5000/). If port 5000 is busy, run the two commands below and open [port 8765](http://127.0.0.1:8765/).

```powershell
$env:PORT = "8765"
.\.venv\Scripts\python.exe app.py
```

Press **Ctrl+C** in PowerShell to stop the server. Run the launch command again after changing `.env`. Restarting clears the in-memory workspace. The app binds to localhost with debug disabled and requires no PowerShell activation or administrator access for ordinary setup.

## Troubleshooting

| Problem | What to check |
|---|---|
| `py -3.13` unavailable | Install Python 3.13.2 with the Windows launcher and reopen PowerShell. |
| Dependencies fail to install | Check internet access and the Python version. Run the install command with the new environment’s Python. |
| Browser cannot connect | Keep the PowerShell server running and verify the port shown there. |
| AI is not configured | Check that the included `.env` is beside `app.py`, then restart. |
| Gemini denies access | Ask the sender to check the configured project's permissions and model access. |
| Gemini is rate-limited or temporarily unavailable | Wait and retry manually. Check your project’s quota in Google AI Studio if it persists. |
| PDF has no readable text | Use a selectable-text PDF or export the content as TXT. |

With Gemini configured, extracted text is sent to Google for token counting and generation. Avoid uploading confidential or personally sensitive material. This package serves one local browser workspace at a time per session and stores study resources in memory.

