import hashlib
import json
import os
import secrets
from dataclasses import dataclass, field
from difflib import SequenceMatcher
from functools import wraps
from io import BytesIO
from pathlib import Path
from threading import RLock
from time import monotonic

from dotenv import load_dotenv
from flask import Flask, Request, jsonify, render_template, request, session
from pydantic import ValidationError
from werkzeug.exceptions import HTTPException

from ai_service import GeminiService
from document_service import Document, ServiceError, extract, verify_source
from schemas import (
    ExamRequest, FeedbackRequest, FlashcardRequest, QuizRequest, SubmitRequest,
    SummaryRequest, TutorRequest,
)

load_dotenv(Path(__file__).resolve().with_name(".env"), encoding="utf-8-sig")


class MemoryUploadRequest(Request):
    def _get_file_stream(self, total_content_length, content_type, filename=None, content_length=None):
        return BytesIO()


@dataclass
class Workspace:
    document: Document
    tokens: int | None
    touched: float = field(default_factory=monotonic)
    resources: dict = field(default_factory=dict)
    quizzes: dict = field(default_factory=dict)
    results: dict = field(default_factory=dict)
    history: list = field(default_factory=list)
    pending: set = field(default_factory=set)


def bounded_put(mapping, key, value, limit=12):
    mapping.pop(key, None)
    mapping[key] = value
    if len(mapping) > limit:
        del mapping[next(iter(mapping))]


def validate_unique(values, *, near=False, answers=None):
    def normalize(value):
        return " ".join(value.casefold().split())

    normalized = [normalize(value) for value in values]
    normalized_answers = None if answers is None else [normalize(answer) for answer in answers]
    for index, current in enumerate(normalized):
        for previous_index, previous in enumerate(normalized[:index]):
            same_answer = normalized_answers is None or normalized_answers[index] == normalized_answers[previous_index]
            if current == previous or (
                near and same_answer and SequenceMatcher(None, current, previous, autojunk=False).ratio() >= 0.9
            ):
                raise ServiceError("invalid_ai_output", "Gemini returned duplicate items.", 502)


def ratio(correct, total):
    return round(100 * correct / total, 2) if total else 0.0


def score_quiz(questions, answers):
    per_question = []
    concepts = {}
    for item in questions:
        selected = answers.get(item["question_id"])
        status = "unanswered" if selected is None else "correct" if selected == item["correct_index"] else "incorrect"
        per_question.append({**item, "selected_index": selected, "status": status})
        counts = concepts.setdefault(item["concept"], {"attempted": 0, "total": 0, "correct": 0})
        counts["total"] += 1
        counts["attempted"] += selected is not None
        counts["correct"] += status == "correct"
    for counts in concepts.values():
        counts["accuracy"] = ratio(counts["correct"], counts["attempted"])
    correct = sum(row["status"] == "correct" for row in per_question)
    unanswered = sum(row["status"] == "unanswered" for row in per_question)
    return {
        "total": len(questions), "correct": correct, "incorrect": len(questions) - correct - unanswered,
        "unanswered": unanswered, "score_percentage": ratio(correct, len(questions)),
        "questions": per_question, "concept_performance": concepts,
    }


def create_app(config=None, ai=None):
    app = Flask(__name__)
    app.request_class = MemoryUploadRequest
    max_bytes = int(os.getenv("MAX_UPLOAD_MB", "10")) * 1024**2
    app.config.update(
        SECRET_KEY=os.getenv("FLASK_SECRET_KEY") or secrets.token_hex(32),
        SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Strict",
        SESSION_COOKIE_SECURE=os.getenv("SESSION_COOKIE_SECURE") == "1",
        MAX_CONTENT_LENGTH=max_bytes + 65536, MAX_UPLOAD_BYTES=max_bytes, MAX_FORM_PARTS=8,
        MAX_PDF_PAGES=int(os.getenv("MAX_PDF_PAGES", "50")),
        MAX_DOCUMENT_WORDS=int(os.getenv("MAX_DOCUMENT_WORDS", "25000")),
        MAX_DOCUMENT_TOKENS=int(os.getenv("MAX_DOCUMENT_TOKENS", "50000")),
        SESSION_TTL_MINUTES=int(os.getenv("SESSION_TTL_MINUTES", "120")), MAX_WORKSPACES=32,
    )
    app.config.update(config or {})
    ai = ai if ai is not None else GeminiService(
        os.getenv("GEMINI_API_KEY", "").strip(), os.getenv("GEMINI_MODEL", "gemini-3.5-flash-lite").strip(),
        app.config["MAX_DOCUMENT_TOKENS"],
    )
    workspaces = {}
    lock = RLock()

    def ok(data, status=200):
        return jsonify(success=True, data=data), status

    @app.errorhandler(ServiceError)
    def service_error(error):
        return jsonify(success=False, error={"code": error.code, "message": str(error)}), error.status

    @app.errorhandler(HTTPException)
    def http_error(error):
        code = {413: "upload_too_large", 404: "not_found", 405: "method_not_allowed"}.get(error.code, "invalid_request")
        message = "The request exceeds the configured size limit." if error.code == 413 else error.description
        return service_error(ServiceError(code, message, error.code))

    @app.errorhandler(Exception)
    def unexpected(error):
        app.logger.error("Request failed (%s)", type(error).__name__)
        return service_error(ServiceError("internal_error", "The request could not be completed.", 500))

    def sweep(now):
        ttl = app.config["SESSION_TTL_MINUTES"] * 60
        expired = {key for key, item in workspaces.items() if now - item.touched >= ttl}
        for key in expired:
            del workspaces[key]

    def active(document_id=None):
        sid = session.get("sid")
        now = monotonic()
        sweep(now)
        item = workspaces.get(sid)
        if item is None:
            if sid:
                raise ServiceError("workspace_expired", "The workspace expired or was cleared. Upload a document.", 410)
            raise ServiceError("missing_document", "Upload a document to start.", 404)
        if document_id is not None and document_id != item.document.id:
            raise ServiceError("stale_document", "This request refers to a different document.", 409)
        item.touched = now
        return item

    def parse(schema):
        if not request.is_json:
            raise ServiceError("invalid_request", "Send a JSON request body.", 415)
        request.max_content_length = 65536
        try:
            return schema.model_validate(request.get_json())
        except ValidationError as exc:
            fields = ", ".join(".".join(map(str, entry["loc"])) or "body" for entry in exc.errors()[:5])
            raise ServiceError("invalid_request", f"Invalid or missing fields: {fields}.") from None

    @app.get("/")
    def index():
        return render_template("index.html")

    @app.get("/api/health")
    def health():
        return ok({"status": "ok", "ai_configured": ai.configured, "model": ai.model, "live_verified": ai.verified})

    @app.post("/api/document/upload")
    def upload():
        if len(request.files.getlist("file")) != 1:
            raise ServiceError("invalid_upload", "Send exactly one file in the multipart file field.")
        with lock:
            sweep(monotonic())
            previous = workspaces.get(session.get("sid"))
        document = extract(
            request.files["file"], app.config["MAX_UPLOAD_BYTES"],
            app.config["MAX_PDF_PAGES"], app.config["MAX_DOCUMENT_WORDS"],
            previous.document if previous else None,
        )
        count = previous.tokens if previous and previous.document.units is document.units else ai.document_tokens(document)
        with lock:
            sid = session.get("sid") or secrets.token_urlsafe(32)
            if workspaces.get(sid) is not previous:
                raise ServiceError("stale_document", "The workspace changed during upload. Try again.", 409)
            sweep(monotonic())
            if sid not in workspaces and len(workspaces) >= app.config["MAX_WORKSPACES"]:
                raise ServiceError("workspace_capacity", "Workspace capacity is temporarily full.", 503)
            session["sid"] = sid
            workspaces[sid] = Workspace(document, count)
        return ok(document.metadata, 201)

    @app.get("/api/document/info")
    def info():
        with lock:
            item = active()
            return ok({
                **item.document.metadata,
                "resources": list(item.resources.values()), "tutor_history": item.history,
                "results": list(item.results.values()),
            })

    @app.delete("/api/document")
    def clear():
        with lock:
            sweep(monotonic())
            workspaces.pop(session.pop("sid", None), None)
        return ok({"cleared": True})

    def generation(task, schema):
        def decorator(validate):
            @wraps(validate)
            def endpoint():
                body = parse(schema)
                options = body.model_dump(exclude={"document_id", "regenerate"})
                key = task + ":" + hashlib.sha256(json.dumps(options, sort_keys=True).encode()).hexdigest()
                with lock:
                    item = active(body.document_id)
                    if task in item.pending:
                        raise ServiceError("generation_in_progress", "This operation is already in progress.", 409)
                    if task != "tutor" and not body.regenerate and key in item.resources:
                        return ok(item.resources[key])
                    if task == "tutor":
                        options["history"] = [
                            {"question": row["preferences"]["question"], "answer": row["content"]["answer"][:1600]}
                            for row in item.history
                        ]
                    if task == "feedback":
                        result = item.results.get(body.result_id)
                        if result is None:
                            raise ServiceError("invalid_result", "This result is unavailable in the current workspace.", 404)
                        options["result"] = {
                            **result, "questions": [q for q in result["questions"] if q["status"] != "correct"],
                        }
                    item.pending.add(task)
                try:
                    output, metrics = ai.generate(task, item.document, options, item.tokens)
                    with lock:
                        if workspaces.get(session.get("sid")) is not item:
                            raise ServiceError("stale_document", "The workspace changed during generation.", 409)
                        active(body.document_id)
                        content = validate(output, body, item)
                        resource = {
                            "document_id": body.document_id, "type": task,
                            "preferences": body.model_dump(exclude={"document_id", "regenerate"}),
                            "content": content, "generation": metrics,
                        }
                        if task == "tutor":
                            item.history = (item.history + [resource])[-5:]
                        else:
                            bounded_put(item.resources, key, resource, 24)
                        return ok(resource)
                finally:
                    with lock:
                        item.pending.discard(task)
            return endpoint
        return decorator

    @app.post("/api/summary")
    @generation("summary", SummaryRequest)
    def summary(output, _body, _item):
        return output.model_dump()

    @app.post("/api/tutor")
    @generation("tutor", TutorRequest)
    def tutor(output, body, item):
        data = output.model_dump()
        sources = [verify_source(item.document, source) for source in output.sources]
        evidence = bool(output.document_supported_content.strip() and output.sufficient_document_evidence
                        and any(source["verified"] for source in sources))
        data.update(sources=sources, sufficient_document_evidence=evidence)
        if not evidence:
            message = "I could not verify sufficient supporting evidence in the uploaded document."
            data.update(answer=message, explanation=message, document_supported_content="")
        if body.knowledge_mode == "extended" and evidence:
            data.update(answer=output.document_supported_content or output.answer, explanation=output.document_supported_content)
        if body.knowledge_mode == "strict":
            data["supplementary_content"] = ""
        return data

    @app.post("/api/quiz/generate")
    @generation("quiz", QuizRequest)
    def quiz(output, body, item):
        if not output.topic_supported and body.topic:
            raise ServiceError("unsupported_topic", "The requested topic is not supported by the document.", 422)
        if not output.topic_supported or len(output.questions) != body.count:
            raise ServiceError("invalid_ai_output", "Gemini returned the wrong number of quiz questions.", 502)
        validate_unique([q.question_id for q in output.questions])
        validate_unique([q.question for q in output.questions], near=True)
        questions = []
        for q in output.questions:
            validate_unique(q.options)
            questions.append({**q.model_dump(), "sources": [verify_source(item.document, s) for s in q.sources]})
        quiz_id = secrets.token_urlsafe(24)
        evicted = next(iter(item.quizzes)) if len(item.quizzes) >= 12 else None
        bounded_put(item.quizzes, quiz_id, questions)
        if evicted is not None:
            for key, value in list(item.resources.items()):
                if value["type"] == "quiz" and value["content"]["quiz_id"] == evicted:
                    del item.resources[key]
        return {
            "quiz_id": quiz_id,
            "questions": [{key: row[key] for key in ("question_id", "question", "options", "concept")} for row in questions],
        }

    @app.post("/api/quiz/submit")
    def submit():
        body = parse(SubmitRequest)
        with lock:
            item = active(body.document_id)
            questions = item.quizzes.get(body.quiz_id)
            if questions is None:
                raise ServiceError("invalid_quiz", "This quiz is unavailable in the current workspace.", 404)
            answers = {answer.question_id: answer.option_index for answer in body.answers}
            if len(answers) != len(body.answers) or answers.keys() - {q["question_id"] for q in questions}:
                raise ServiceError("invalid_answers", "Use unique question IDs from the submitted quiz.")
            result_id = secrets.token_urlsafe(24)
            result = {
                **score_quiz(questions, answers), "document_id": body.document_id,
                "quiz_id": body.quiz_id, "result_id": result_id,
            }
            evicted = next(iter(item.results)) if len(item.results) >= 12 else None
            bounded_put(item.results, result_id, result)
            if evicted is not None:
                for key, value in list(item.resources.items()):
                    if value["type"] == "feedback" and value["preferences"]["result_id"] == evicted:
                        del item.resources[key]
            return ok(result)

    @app.post("/api/quiz/feedback")
    @generation("feedback", FeedbackRequest)
    def feedback(output, body, item):
        if body.result_id not in item.results:
            raise ServiceError("invalid_result", "This result is unavailable in the current workspace.", 404)
        return output.model_dump()

    @app.post("/api/flashcards")
    @generation("flashcards", FlashcardRequest)
    def flashcards(output, body, _item):
        if len(output.cards) != body.count:
            raise ServiceError("invalid_ai_output", "Gemini returned the wrong number of flashcards.", 502)
        validate_unique([card.card_id for card in output.cards])
        validate_unique([card.front for card in output.cards], near=True, answers=[card.back for card in output.cards])
        return output.model_dump()

    @app.post("/api/exam-prep")
    @generation("exam_prep", ExamRequest)
    def exam(output, body, _item):
        if body.mode == "quick_revision":
            valid = bool(output.sections) and not output.questions
        else:
            answered = body.mode in {"short_answers", "descriptive_answers"}
            valid = bool(output.questions) and all((q.model_answer is not None) == answered for q in output.questions)
        if not valid:
            raise ServiceError("invalid_ai_output", "Gemini returned content inconsistent with the preparation mode.", 502)
        return {
            **output.model_dump(),
            "practice_notice": "AI-generated practice recommendations. Actual examination questions may differ."
            if output.questions else None,
        }

    return app


app = create_app()


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=int(os.getenv("PORT", "5000")), debug=False)

