import hashlib
import re
import uuid
from dataclasses import dataclass, replace
from pathlib import PureWindowsPath

import pymupdf


class ServiceError(Exception):
    def __init__(self, code, message, status=400):
        super().__init__(message)
        self.code = code
        self.status = status


@dataclass(frozen=True)
class Document:
    metadata: dict
    units: tuple[str, ...]
    context: str
    digest: str

    @property
    def id(self):
        return self.metadata["document_id"]


def normalize(text):
    return " ".join(text.split())


def read_txt(raw):
    try:
        if raw.startswith((b"\xff\xfe", b"\xfe\xff")):
            value = raw.decode("utf-16")
        else:
            try:
                value = raw.decode("utf-8-sig")
            except UnicodeDecodeError:
                value = raw.decode("cp1252")
    except UnicodeError:
        raise ServiceError("invalid_encoding", "Use UTF-8, BOM-marked UTF-16 or Windows-1252 text.") from None
    if re.search(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f-\x9f]", value):
        raise ServiceError("invalid_encoding", "The TXT file contains binary or unsupported control characters.")
    return tuple(line.rstrip() for line in value.splitlines())


def read_pdf(raw, max_pages, max_words):
    if b"%PDF-" not in raw[:1024]:
        raise ServiceError("invalid_pdf", "The file is not a readable PDF.")
    try:
        with pymupdf.open(stream=raw, filetype="pdf") as pdf:
            if pdf.needs_pass:
                raise ServiceError("protected_pdf", "Remove the PDF password before uploading.")
            if pdf.page_count > max_pages:
                raise ServiceError("document_too_large", f"PDFs may contain at most {max_pages} pages.", 413)
            pages = []
            words = 0
            for page in pdf:
                content = page.get_text(sort=True).strip()
                words += len(content.split())
                if words > max_words:
                    raise ServiceError("document_too_large", f"Documents may contain at most {max_words} extracted words.", 413)
                pages.append(content)
            return tuple(pages)
    except (RuntimeError, ValueError):
        raise ServiceError("invalid_pdf", "The PDF is corrupted or unreadable.") from None


def extract(file, max_bytes, max_pages, max_words, previous=None):
    filename = PureWindowsPath(file.filename or "").name
    kind = PureWindowsPath(filename).suffix.lower().lstrip(".")
    if kind not in {"pdf", "txt"}:
        raise ServiceError("unsupported_format", "Upload a PDF or TXT file.", 415)
    raw = file.stream.read(max_bytes + 1)
    if len(raw) > max_bytes:
        raise ServiceError("upload_too_large", "The file exceeds the upload size limit.", 413)
    if not raw:
        raise ServiceError("empty_file", "The uploaded file is empty.")
    digest = hashlib.sha256(raw).hexdigest()
    if previous and previous.digest == digest and previous.metadata["source_type"] == kind:
        return replace(previous, metadata={**previous.metadata, "document_id": uuid.uuid4().hex, "filename": filename})
    if kind == "txt" and raw.lstrip().startswith(b"%PDF-"):
        raise ServiceError("unsupported_format", "Use the PDF extension for PDF files.", 415)
    units = read_pdf(raw, max_pages, max_words) if kind == "pdf" else read_txt(raw)
    combined = "\n".join(units)
    words = len(combined.split())
    if words < 3 or not any(char.isalpha() for char in combined):
        raise ServiceError("insufficient_text", "The file has too little readable text. Scanned PDFs require a text layer.", 422)
    if words > max_words:
        raise ServiceError("document_too_large", f"Documents may contain at most {max_words} extracted words.", 413)
    label = "Page" if kind == "pdf" else "Line"
    context = "\n".join(f"[{label} {number}] {value}" for number, value in enumerate(units, 1))
    metadata = {
        "document_id": uuid.uuid4().hex, "filename": filename, "source_type": kind,
        "size_bytes": len(raw), "page_count": len(units) if kind == "pdf" else None,
        "line_count": sum(len(unit.splitlines()) for unit in units) if kind == "pdf" else len(units),
        "word_count": words, "preview": combined[:1600],
        "unreadable_pages": [i for i, value in enumerate(units, 1) if not value] if kind == "pdf" else [],
    }
    return Document(metadata, units, context, digest)


def verify_source(document, source):
    excerpt = normalize(source.excerpt)
    candidate = ""
    if source.source_type == document.metadata["source_type"] == "pdf":
        if source.page and 1 <= source.page <= len(document.units) and source.line_start is None and source.line_end is None:
            candidate = document.units[source.page - 1]
    if source.source_type == document.metadata["source_type"] == "txt":
        start, end = source.line_start, source.line_end
        if source.page is None and start and end and 1 <= start <= end <= len(document.units):
            candidate = "\n".join(document.units[start - 1:end])
    return {**source.model_dump(), "verified": bool(excerpt and excerpt in normalize(candidate))}

